# AIO MODULE

## Install

### Add library
Best thing is to use the Arduino Library Manager.
* Go to Sketch > Include Library > Manage Libraries.
* Install WebSockets by Markus Sattler
* Install ArduinoJson

##  Example
see [Example](examples)


